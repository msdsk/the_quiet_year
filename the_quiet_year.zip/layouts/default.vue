<template>
  <div class="container">
    <nuxt/>
  </div>
</template>

<style  src="~/assets/global.css">
</style>
